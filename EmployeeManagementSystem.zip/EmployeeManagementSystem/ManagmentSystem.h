
#pragma once

#include "Employee.h"
#include "Boss.h"
#include "Programmer.h"
#include "Designer.h"



class ManagmentSystem
{
    Boss* director;
    void addMenu(string& name, string& surname, long long* salary, string& depName)
    {
        int i;
        cout << "Is this the boss? 1 - yes | 2 - no\n- ";
        try
        {
            cin >> i;
            if (i < 1 || i > 2) { throw runtime_error("Wrong number"); }
            switch (i)
            {
            case 1:
                cout << "Enter department name - ";
                cin.ignore();
                getline(cin, depName);
                cin.clear();
                break;
            case 2:
                break;
            }
            cout << "Enter name - ";

            cin >> name;
            cout << "Enter surname - ";

            cin >> surname;
            cout << "Enter salary - ";
            cin >> *salary;
        }
        catch (exception& ex)
        {
            cout << ex.what();
            addMenu(name, surname, salary, depName);
        }
    }
public:
    ManagmentSystem(Boss* director) : director(director) {}
    ManagmentSystem(const string& name, const string& surname, long long salary)
        : director(new Boss(name, surname, salary, "Company")) {}

    void addEmployee()
    {
        string bossName;
        string bossSurname;
        cout << "Enter Boss name - ";
        cin >> bossName;
        cout << "Enter Boss surname - ";
        cin >> bossSurname;
        Employee* temp = director->findEmployee(bossName, bossSurname);
        if (temp) {
            string name, surname, depName;
            long long salary;
            addMenu(name, surname, &salary, depName);
            if (depName.size() > 0)
            {
                temp->addEmployee(new Boss(name, surname, salary, depName));
            }
            else {
                int choice = 0;
                while (choice < 1 || choice > 2) {
                    cout << "Choise position 1 - programmer | 2 - designer\n- ";
                    cin >> choice;
                }
                switch (choice) {
                case 1:
                    temp->addEmployee(new Programmer(name, surname, salary));
                    break;
                case 2:
                    temp->addEmployee(new Designer(name, surname, salary));
                    break;
                }
            }
        }
        else
        {
            cout << "Not found boss";
        }
    }

    void print() const
    {
        director->print(0);
    }
    double salaryCount() const
    {
        return director->salaryCount();
    }
    ~ManagmentSystem()
    {
        if (director)
            delete director;
    }
};

