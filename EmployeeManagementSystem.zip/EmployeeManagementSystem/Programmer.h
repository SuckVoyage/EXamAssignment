#pragma once
#include "Employee.h"

class Programmer : public Employee
{
public:
    Programmer(const string& name, const string& surname, float salary) : Employee(name, surname, salary) {}
    
    string getPosition() const override { return "programmer"; }
};

