﻿// EmployeeManagementSystem.cpp 
#include <iostream>

#include "ManagmentSystem.h"



int main() {
    Boss* head = new Boss("Peter", "Petrov", 1'300'000, "Company");
    head->addEmployee(new Programmer("Vasia", "Ivanov", 1'100'000));
    head->addEmployee(new Programmer("Maxim", "Kuznetsov",130'000));
    head->addEmployee(new Programmer("Vasia", "Ivanov", 1'100'000));
    head->addEmployee(new Programmer("Maxim", "Kuznetsov", 130'000));
    Employee* temp = new Boss("Vasia", "Pupkin", 1'100'000, "Programming");
    temp->addEmployee(new Programmer("Vasia", "Ivanov", 1'100'000));
    temp->addEmployee(new Programmer("Vasia", "Ivanov", 1'100'000));
    temp->addEmployee(new Programmer("Vasia", "Ivanov", 1'100'000));
    head->addEmployee(temp);
    ManagmentSystem oao(head);
    oao.print();
   /* for (int i = 0; i < 2; i++) {
        oao.addEmployee();
        oao.print();
    }*/
    cout << endl << (unsigned int)oao.salaryCount() << endl;
    return 0;
}
