#pragma once

#include "Employee.h"
#include "Programmer.h"
#include <vector>

class Boss : public Employee
{
    string departmentName;
    vector<Employee*> staff;
public:
    Boss(const string& name, const string& surname, double salary, const string& depName)
        : Employee(name, surname, salary), departmentName(depName) {}

    string getPosition() const override
    {
        return "Head of " + departmentName;
    }
    void addEmployee(Employee* employee) override
    {
        staff.push_back(employee);
    }

    Employee* findEmployee(const string& name, const string& surname) override
    {
        if (name + surname == getFullName())
            return this;
        else
        {
            for (Employee* person : staff)
            {
                Employee* temp = person->findEmployee(name, surname);
                if (temp)
                {
                    return temp;
                }
            }
            return nullptr;
        }
    }

    long long salaryCount() const override
    {
        long long temp = 0;
        for (Employee* person : staff)
        {
            temp += person->salaryCount();
        }
        return salary + temp;
    }

    void print(int depth) const override
    {
        for (int i = 0; i < depth; i++)
            cout << "   ";
        cout << "Position - " << getPosition() << endl;
        for (int i = 0; i < depth; i++)
            cout << "   ";
        cout << surname << " " << name << " - " << salary << endl << endl;
        for (Employee* person : staff)
        {
            person->print(depth + 1);
        }
    }

    ~Boss()
    {
        for (Employee* person : staff)
        {
            delete person;
        }
    }
};


